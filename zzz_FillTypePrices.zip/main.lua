-- set this variable to a number and it will change price factor of ALL fill types (also overrides values in the list below)
local globalFillTypeStartPriceFactor = false

local fillTypeStartPriceFactor = {
    Barley = 1.0,
    Canola = 1.0,
    Chaff = 1.0,
    Cotton = 1.0,
    Maize = 1.0,
    Oat = 1.0,
    Potato = 1.0,
    Silage = 1.0,
    Soybean = 1.0,
    Straw = 1.0,
    Sugarbeet = 1.0,
    Sugarcane = 1.0,
    Sunflower = 1.0,
    Wheat = 1.0,
    Woodchips = 1.0,
    Wool = 1.0,
    -- misc
    Chaff = 1.0,
    DEF = 1.0,
    Diesel = 1.0,
    Manure = 1.0,
    Milk = 1.0,
}

-- Other possible fillTypes you can add to fillTypeStartPriceFactor list:

-- CHICKEN_TYPE_BLACK
-- CHICKEN_TYPE_BROWN
-- CHICKEN_TYPE_ROOSTER
-- CHICKEN_TYPE_WHITE
-- COW_TYPE_BLACK
-- COW_TYPE_BLACK_WHITE
-- COW_TYPE_BRAHMAN_BROWN
-- COW_TYPE_BRAHMAN_GREY
-- COW_TYPE_BRAHMAN_LIGHT_BROWN
-- COW_TYPE_BRAHMAN_WHITE
-- COW_TYPE_BROWN
-- COW_TYPE_BROWN_WHITE
-- DIGESTATE
-- DRYGRASS
-- DRYGRASS_WINDROW
-- EGG
-- FERTILIZER
-- FORAGE
-- FORAGE_MIXING
-- FUEL
-- GRASS
-- GRASS_WINDROW
-- HERBICIDE
-- HORSE_TYPE_BEIGE
-- HORSE_TYPE_BLACK
-- HORSE_TYPE_BROWN
-- HORSE_TYPE_BROWN_WHITE
-- HORSE_TYPE_DARK_BROWN
-- HORSE_TYPE_GREY
-- HORSE_TYPE_LIGHT_BROWN
-- HORSE_TYPE_RED_BROWN
-- LIME
-- LIQUIDFERTILIZER
-- LIQUIDMANURE
-- OILSEEDRADISH
-- PIGFOOD
-- PIG_TYPE_BLACK
-- PIG_TYPE_BLACK_WHITE
-- PIG_TYPE_RED
-- PIG_TYPE_WHITE
-- POPLAR
-- ROUNDBALE
-- ROUNDBALE_BARLEY
-- ROUNDBALE_DRYGRASS
-- ROUNDBALE_GRASS
-- ROUNDBALE_WHEAT
-- SEEDS
-- SHEEP_TYPE_BLACK
-- SHEEP_TYPE_BLACK_WHITE
-- SHEEP_TYPE_BROWN
-- SHEEP_TYPE_WHITE
-- SQUAREBALE
-- SQUAREBALE_BARLEY
-- SQUAREBALE_WHEAT
-- TARP
-- TREESAPLINGS
-- WATER


-- example:
-- fillTypeStartPriceFactor.EGG = 2


function updateFillTypePrices()
    local count = 0
    if globalFillTypeStartPriceFactor == false then
        for name, factor in pairs(fillTypeStartPriceFactor) do
            local fillType = g_fillTypeManager.nameToFillType[string.upper(name)]
            if fillType ~= nil and factor ~= 1 then
                fillType.startPricePerLiter = fillType.startPricePerLiter * factor
                fillType.pricePerLiter = fillType.pricePerLiter * factor
                count = count + 1
            end
        end
    elseif globalFillTypeStartPriceFactor ~= 1 then
        for _, fillType in pairs(g_fillTypeManager.fillTypes) do
            fillType.startPricePerLiter = fillType.startPricePerLiter * globalFillTypeStartPriceFactor
            fillType.pricePerLiter = fillType.pricePerLiter * globalFillTypeStartPriceFactor
            count = count + 1
        end
    end
    print('FillTypePrices > Changed price factor on ' .. tostring(count) .. ' entries')
end

local FillTypePrices = {}

function FillTypePrices:loadMap()
    updateFillTypePrices();
end


addModEventListener(FillTypePrices)